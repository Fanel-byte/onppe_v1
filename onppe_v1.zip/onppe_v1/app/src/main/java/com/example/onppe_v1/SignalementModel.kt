package com.example.onppe_v1
import androidx.lifecycle.ViewModel

class SignalementModel:ViewModel() {var signalements = listOf<Signalement>()}