package com.example.onppe_v1

const val url = "https://b3f6-41-220-147-140.ngrok-free.app/"